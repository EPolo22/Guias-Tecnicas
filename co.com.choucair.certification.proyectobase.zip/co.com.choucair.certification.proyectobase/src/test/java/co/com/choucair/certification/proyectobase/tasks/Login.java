package co.com.choucair.certification.proyectobase.tasks;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;

public class Login implements Task {
    public static Login OnThePage() {
        return  Tasks.instrumented(Login.class);
    }

    @Override
    public <T extends Actor> void performAs (T actor)
    {

    }
}
